# Automação de Relatório Excel com Python 📊

Este projeto automatiza a criação de um relatório de salários com base em um arquivo de entrada com horas trabalhadas e valor por hora.

## Funcionalidades

- Leitura de dados em CSV
- Cálculo automático do salário
- Geração de planilha Excel formatada

## Como executar

1. Instale os pacotes necessários:
   pip install pandas openpyxl

2. Execute o script:
   python automacao_excel.py

## Autor

Elias Rodrigues – Estudante de Sistemas para Internet | 2º período
