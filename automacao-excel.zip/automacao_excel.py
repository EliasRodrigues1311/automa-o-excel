import pandas as pd

# Ler o arquivo CSV
df = pd.read_csv('dados/horas_trabalhadas.csv')

# Calcular o salário
df['Salário'] = df['Horas Trabalhadas'] * df['Valor Hora']

# Salvar como novo Excel formatado
df.to_excel('relatorio_salarios.xlsx', index=False)

print("Relatório gerado com sucesso!")
